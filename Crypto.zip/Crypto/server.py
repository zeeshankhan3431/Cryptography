import socket
from getmac import get_mac_address

port=5050
ip = 'localhost'
print(socket.gethostname())
soc=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
mac = get_mac_address(ip="192.168.56.1")
name=socket.gethostname()
soc.bind((ip,port))
soc.listen()


def encrypt(message, shift):
    cipher = ''
    message=message.upper()
    for char in message:

        if char == ' ':
            cipher = cipher + char
        else:
            cipher = cipher + chr((ord(char) + shift - 65) % 26 + 65)

    return cipher


text = input("enter string: ")
s = int(input("enter shift number: "))
print("original string: ", text)
encrypted=encrypt(text, s)
print("after encryption: ",encrypted )



client, address = soc.accept()
print ('Connecting from: ' + str(address) )
print ('Connecting from: ' + str(client) )
client.send(bytes(name, 'utf8'))
client.send(bytes(mac,  'utf8'))
client.send(bytes(encrypted, 'utf8'))

print(client.recv(1024).decode())




