import socket
import string, sys
host = 'localhost'
port = 5050
buffer_size = 1024
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))

print('connected')
print('DesktopName:', s.recv(1024).decode())
print ('MacAddress:', s.recv(1024).decode())

letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def brute_force(message):
    for shift in range (26):
      cipher = message
      cipher=cipher.upper()
      plainTxt=""
      for char in cipher:
         location=letters.find(char)
         new_location= (location - int(shift)) % 26

         if char in letters:
            plainTxt += letters[new_location]
         else:
            plainTxt +=char
      shift=str(shift)
      print("Message:",plainTxt)


text = s.recv(1024).decode()
plain_txt=brute_force(text)



# s.close()

